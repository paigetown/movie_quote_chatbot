# Activity 1
def set_value(board, i, j, n):
    board[i][j] = n

def print_value(board):
    for i in board:
        for j in i:
            print(j, end= '')
        print()


sudoku = [[0,0,9,6,0,7,4,3,1],
	   	 [8,0,0,0,5,3,0,0,9],
	   	 [0,6,0,2,0,0,5,0,0],
	   	 [4,0,0,1,0,2,6,5,0]]

set_value(sudoku, 3, 0 ,9)
print_value(sudoku)

# Activity 2
def nested_avg(nested_ints):
    avg = []
    for row in nested_ints:
        sum = 0
        for col in row:
            sum += col
        average = sum / len(row)
        avg.append(average)
    return avg

numbers = [[1,2], [3], [4,5,6]]
list_avg = nested_avg(numbers)
print(list_avg)

# Activity 3
def greyscale(image):
    for row in image:
        for col in row:
            avg = (col[0] + col[1] + col[2]) // 3
            col[0] = avg
            col[1] = avg
            col[2] = avg
    return image

image = [ [ [ 0, 255, 0 ], [ 255, 0, 0 ] ], [ [ 0, 0, 255 ], [ 255, 255, 255 ] ] ]
print(greyscale(image))

# Activity 4
A = {
    'Afghanistan':{
        'life':[28.21, 28.2, 28.19, ... , 53.8],
        'pop':[3280000, 3284351, ... , 32526562],
        'gdp':[603.0, 604.0, ... , 1925.0]
    },
    'Albania':{
        'life':[...],
        'pop':[...],
        'gdp':[...]
    }
    # ...
}
# This is a dictionary of a dictionary of a list

B = {
    '1800':{
        'Afghanistan':{'life':28.21, 'pop':3280000, 'gdp':603.0},
        'Albania':{...}
    },
    '1801':{
        'Afghanistan':{...}
    }
}
# This is a dictionary within a dictionary within a dictionary